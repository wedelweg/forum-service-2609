package cohort_65.java.forumservice.accounting.dto;

import lombok.Getter;

@Getter
public class UserUpdateDto {
    String firstName;
    String lastName;
}
