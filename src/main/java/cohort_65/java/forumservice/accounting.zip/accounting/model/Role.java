package cohort_65.java.forumservice.accounting.model;

public enum Role {
    USER, MODER, ADMIN;
}
